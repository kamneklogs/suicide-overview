Suicide Overview (1986-2016)

Use instructions:

1. Run suicide-overview.exe
2. Select the data source (SuicideData.csv in the same folder) or download the .csv file from https://www.kaggle.com/russellyates88/suicide-rates-overview-1985-to-2016
3. Enjoy the app.
